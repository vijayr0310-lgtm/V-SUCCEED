<?php
require_once "config.php";

$success = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["student_name"] ?? "");
    $phone = trim($_POST["contact_number"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $location = trim($_POST["location"] ?? "");
    $course = trim($_POST["course"] ?? "");

    if ($name === "" || $phone === "" || $email === "" || $location === "" || $course === "") {
        $error = "Please fill all fields.";
    } else {
        $stmt = $pdo->prepare("INSERT INTO students (student_name, contact_number, email, location, course) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$name, $phone, $email, $location, $course]);
        $success = "Registration successful!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>V SUCCEED</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="top">
        <div class="logo">HV <span>Technologies</span></div>
        <div class="menu">
            <a href="#home">Home</a>
            <a href="#courses">Courses</a>
            <a href="#register">Register</a>
            <a href="#contact">Contact</a>
            <a href="admin.php">Admin</a>
        </div>
    </nav>

    <section id="home" class="hero">
        <h1>HV <span>Technologies</span> 🚀</h1>
        <p>Empowering Students with Future Skills</p>
        <a href="#register" class="btn">Register Now</a>
    </section>

    <section id="courses" class="section">
        <h2 class="title">Our Courses</h2>
        <div class="course-grid">
            <div class="card"><h3>Web Development</h3><p>HTML, CSS, JavaScript, PHP</p></div>
            <div class="card"><h3>Data Analytics</h3><p>Excel, SQL, Python, Power BI</p></div>
            <div class="card"><h3>Digital Marketing</h3><p>SEO, Google Ads, Social Media</p></div>
            <div class="card"><h3>Python Programming</h3><p>Basics to Advanced</p></div>
        </div>
    </section>

    <section id="register" class="section">
        <h2 class="title">Student Registration</h2>
        <div class="form-wrap">
            <?php if ($success): ?><p class="success"><?php echo htmlspecialchars($success); ?></p><?php endif; ?>
            <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
            <form method="POST" action="">
                <input type="text" name="student_name" placeholder="Student Name" required>
                <input type="text" name="contact_number" placeholder="Contact Number" required>
                <input type="email" name="email" placeholder="E-mail" required>
                <input type="text" name="location" placeholder="Location" required>
                <select name="course" required>
                    <option value="">Select Course</option>
                    <option>Web Development</option>
                    <option>Data Analytics</option>
                    <option>Digital Marketing</option>
                    <option>Python Programming</option>
                </select>
                <button type="submit" class="btn">Register</button>
            </form>
        </div>
    </section>

    <section id="contact" class="section">
        <h2 class="title">Contact Us</h2>
        <div class="contact-box">
            <div class="contact-card"><h3>📍 Location</h3><p>Chennai</p></div>
            <div class="contact-card"><h3>📞 Contact Numbers</h3><p>9363359354</p><p>9884210213</p></div>
        </div>
        <div class="map-box">
            <iframe src="https://www.google.com/maps?q=Chennai&output=embed" width="100%" height="280" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
        </div>
    </section>

    <footer><p>© 2026 V SUCCEED | All Rights Reserved</p></footer>
</body>
</html>
