<?php
require_once "config.php";
$stmt = $pdo->query("SELECT * FROM students ORDER BY id DESC");
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - V SUCCEED</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="top">
        <div class="logo">HV <span>Technologies</span></div>
        <div class="menu">
            <a href="index.php">Home</a>
            <a href="admin.php">Admin</a>
        </div>
    </nav>

    <section class="section">
        <h2 class="title">Admin Dashboard</h2>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Student Name</th>
                        <th>Contact Number</th>
                        <th>Email</th>
                        <th>Location</th>
                        <th>Course</th>
                        <th>Created At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($students) > 0): ?>
                        <?php foreach ($students as $student): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($student["id"]); ?></td>
                                <td><?php echo htmlspecialchars($student["student_name"]); ?></td>
                                <td><?php echo htmlspecialchars($student["contact_number"]); ?></td>
                                <td><?php echo htmlspecialchars($student["email"]); ?></td>
                                <td><?php echo htmlspecialchars($student["location"]); ?></td>
                                <td><?php echo htmlspecialchars($student["course"]); ?></td>
                                <td><?php echo htmlspecialchars($student["created_at"]); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="7">No student records found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</body>
</html>
