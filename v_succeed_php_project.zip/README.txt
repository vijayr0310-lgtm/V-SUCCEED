V SUCCEED PHP + MySQL Project Setup

1. Install XAMPP
2. Copy this folder into:
   C:\xampp\htdocs\hv_technolyies

3. Start Apache and MySQL in XAMPP
4. Open phpMyAdmin
5. Import database.sql
6. Open browser:
   http://localhost/hv_technolyies/index.php

Admin page:
   http://localhost/hv_technolyies/admin.php
